package com.iesalixar.jjoselibreroc.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.iesalixar.jjoselibreroc.controller.dto.UserRegistrationDto;
import com.iesalixar.jjoselibreroc.model.User;


public interface UserService extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);
}

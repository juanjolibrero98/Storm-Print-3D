package org.iesalixar.jjoselibreroc;

import org.iesalixar.jjoselibreroc.model.User;
import org.iesalixar.jjoselibreroc.repository.RoleRepository;
import org.iesalixar.jjoselibreroc.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class StormPrint3DApplication {

	public static void main(String[] args) {
		SpringApplication.run(StormPrint3DApplication.class, args);
	}

	
//	@Bean
//	CommandLineRunner initData(UserRepository userRepository, RoleRepository roleRepository) {
//		return (args) -> {
//			
//			User admin = new User();
//			admin.setFirstName(null);
//			admin.setLastName(null);
//			admin.setPassword(null);
//			admin.setRoles(null);
//		};
//	}
}

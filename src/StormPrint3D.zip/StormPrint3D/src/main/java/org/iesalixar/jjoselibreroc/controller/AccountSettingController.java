package org.iesalixar.jjoselibreroc.controller;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.iesalixar.jjoselibreroc.model.AccountSetting;
import org.iesalixar.jjoselibreroc.model.Filament;
import org.iesalixar.jjoselibreroc.model.User;
import org.iesalixar.jjoselibreroc.service.AccountSettingService;
import org.iesalixar.jjoselibreroc.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class AccountSettingController {

	
	@Autowired
	private AccountSettingService accountSettingService; 
	
	@Autowired
	UserServiceImpl userService;
	
	@GetMapping("/profile")
	public String profile(Model model) {
		model.addAttribute("profileOK", false);
		model.addAttribute("profileNoOK", false);
		
		User user = userService.returnUser();
		if(user.getAccountSetting() != null) {
			model.addAttribute("profileOK", true);
			model.addAttribute("userProfile", user.getAccountSetting());
			
		}else {
			model.addAttribute("profileNoOK", true);
			model.addAttribute("newProfile", new AccountSetting());
		}
		return "user/profile";
	}
	
//	@GetMapping("/profile")
//	public String profile(Model model) {
//		model.addAttribute("newProfile", new AccountSetting());
//		return "user/profile";
//	}
	
	@PostMapping("/profile/submit")
	public String createAccountSettingSubmit(@ModelAttribute AccountSetting profile) {
		User user = userService.returnUser();
		profile.setUser(user);
		accountSettingService.createProfile(profile);
		return "redirect:/profile";
	}
	
	@PostMapping("/updateProfile")
	public String updateProfile(@ModelAttribute AccountSetting profileUpdate) {
		accountSettingService.updateProfile(profileUpdate);		
		return "redirect:/profile";		
	}
	
	@PostMapping("/upload")
//	public ResponseEntity<?> upload( @RequestParam("archivo") MultipartFile archivo){
	public String upload( @ModelAttribute MultipartFile images){
		User user = userService.returnUser();
		AccountSetting profile = user.getAccountSetting();
		Map<String, Object> response = new HashMap<>();
		
		if(!images.isEmpty()) {//si hay
			String nombreArchivo = UUID.randomUUID().toString() +"_"+ images.getOriginalFilename().replace(" ", "");
			
			Path rutaArchivo = Paths.get("uploads/profile").resolve(nombreArchivo).toAbsolutePath();

			System.out.println(rutaArchivo.toString());

			try {
				Files.copy(images.getInputStream(), rutaArchivo);
			} catch (Exception e) {

				response.put("mensaje", "Error al subir la imagen del cliente " + nombreArchivo);
				response.put("error", e.getMessage().concat(" : ").concat(e.getCause().getMessage()));
//				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR); 
				return "redirect:/profile";
			}
			
			String nombreFotoAnterior = profile.getImages();
			if(nombreFotoAnterior != null && nombreFotoAnterior.length() > 0) {
				Path rutaFotoAnterior = Paths.get("uploads/profile").resolve(nombreFotoAnterior).toAbsolutePath();
				File archivoFotoAnterior = rutaFotoAnterior.toFile();
				if(archivoFotoAnterior.exists() && archivoFotoAnterior.canRead()) {
					archivoFotoAnterior.delete();
				}
			} 
			
			profile.setImages(nombreArchivo);
			accountSettingService.createProfile(profile);
			user.setAccountSetting(profile);
			userService.saveUser(user);
		
			response.put("cliente", profile);
			response.put("mensaje", "Has subido correctamente la imagen: "+ nombreArchivo);
		}
		
//		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.CREATED);
		return "redirect:/profile";
	}
	
	
}

package org.iesalixar.jjoselibreroc.controller;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.iesalixar.jjoselibreroc.model.AccountSetting;
import org.iesalixar.jjoselibreroc.model.Filament;
import org.iesalixar.jjoselibreroc.model.Part;
import org.iesalixar.jjoselibreroc.model.Printer;
import org.iesalixar.jjoselibreroc.model.Role;
import org.iesalixar.jjoselibreroc.model.User;
import org.iesalixar.jjoselibreroc.service.AccountSettingService;
import org.iesalixar.jjoselibreroc.service.FilamentService;
import org.iesalixar.jjoselibreroc.service.PartService;
import org.iesalixar.jjoselibreroc.service.PrinterService;
import org.iesalixar.jjoselibreroc.service.RoleService;
import org.iesalixar.jjoselibreroc.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AdminController {

	@Autowired
	PrinterService printerService;
	
	@Autowired
	FilamentService filamentService;
	
	@Autowired
	PartService partService;
	
	@Autowired
	AccountSettingService accountSettingService;
	
	@Autowired
	RoleService roleService;
	
	@Autowired
	UserServiceImpl userService;
	
	
	@GetMapping("/getPrinters")
	public String printers(Model model) {
		model.addAttribute("printerlist", printerService.findAll());
		return "admin/printerRegistered";
	}	

	@GetMapping("/getUsers")
	public String users(Model model) {
		model.addAttribute("userlist", userService.findAll());
		return "admin/users";
	}
	
	
	@GetMapping("/users/delete/{email}")
	public String removee(@PathVariable("email") String email) {
		User user = userService.findByEmail(email);
		
		if(user.getAccountSetting() != null) {
			AccountSetting settingUser = user.getAccountSetting();
			accountSettingService.remove(settingUser);
			user.setAccountSetting(null);
		}
		
		
		if(user.getPart() != null) {
			List<Part> parts = user.getPart();
	 		for (Part part : parts) {
	 			part.setPrinter(null);
	 			part.setFilament(null);
	 			parts.remove(part);
	 			partService.removePart(part);
			}
//			user.setPart(null);
		}
		
		if(user.getPrinter() != null) {
			List<Printer> printers = user.getPrinter();
			for (Printer printer : printers) {
				printers.remove(printer);
				printerService.removePrinter(printer);
			}
//			user.setPrinter(null);
		}
		
		if(user.getFilament() != null) {
			List<Filament> filaments = user.getFilament();
			for (Filament filament : filaments) {
				filaments.remove(filament);
				filamentService.removeFilament(filament);
			}
//			user.setFilament(null);
		}
		
		if(user.getRoles() != null) {
			Collection<Role> role = user.getRoles();
			for (Role role2 : role) {
				role.remove(role2);
				roleService.removeRole(role2);
			}
//			user.setRoles(null);
		}
		
		userService.remove(user);
		return "redirect:/getUsers";
	}
	
	@PostMapping("/updateRole")
	public String updateRole(@RequestParam String username, @RequestParam String role) {
		User user = userService.findByEmail(username);
		Collection<Role> roles = user.getRoles();
		for (Role role2 : roles) {
			role2.setName(role);
		}
		user.setRoles(roles);
		userService.saveUser(user);
		return "redirect:/getUsers";		
	}
}

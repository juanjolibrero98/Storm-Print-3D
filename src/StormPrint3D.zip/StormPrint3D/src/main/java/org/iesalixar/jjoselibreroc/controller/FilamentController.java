package org.iesalixar.jjoselibreroc.controller;

import org.iesalixar.jjoselibreroc.model.Filament;
import org.iesalixar.jjoselibreroc.model.Printer;
import org.iesalixar.jjoselibreroc.model.User;
import org.iesalixar.jjoselibreroc.service.FilamentService;
import org.iesalixar.jjoselibreroc.service.PrinterService;
import org.iesalixar.jjoselibreroc.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class FilamentController {

	@Autowired
	FilamentService filamentService;
	
	@Autowired
	UserServiceImpl userService;
	
	
	@GetMapping("/filament")
	public String filament(Model model) {
		model.addAttribute("filamentlist", filamentService.findAllFilamentOfUser());
		return "user/filament";
	}	

	@GetMapping("/createFilament")
	public String createFilament(Model model) {
		model.addAttribute("newFilament", new Filament());
		return "user/createFilament";
	}
	@PostMapping("/createFilament/submit")
	public String createFilamentSubmit(@ModelAttribute Filament filament) {
		filamentService.createFilament(filament);
		User user = userService.returnUser();
		user.getFilament().add(filament);
		userService.saveUser(user);
		return "redirect:/filament";
	}
	
	@GetMapping("/filament/delete/{numIdentify}")
	public String removee(@PathVariable("numIdentify") int numIdentify) {
		filamentService.remove(numIdentify);
		return "redirect:/filament";
	}
	
	@PostMapping("/updateFilament")
	public String updateFilament(@ModelAttribute Filament filamentUpdate) {
		filamentService.updateFilament(filamentUpdate);		
		return "redirect:/filament";		
	}
}

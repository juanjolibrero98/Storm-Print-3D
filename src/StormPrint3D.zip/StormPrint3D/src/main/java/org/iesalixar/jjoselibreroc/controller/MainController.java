package org.iesalixar.jjoselibreroc.controller;

import java.util.List;

import javax.annotation.PostConstruct;

import org.iesalixar.jjoselibreroc.model.AccountSetting;
import org.iesalixar.jjoselibreroc.model.Printer;
import org.iesalixar.jjoselibreroc.model.User;
import org.iesalixar.jjoselibreroc.service.AccountSettingService;
import org.iesalixar.jjoselibreroc.service.PrinterService;
import org.iesalixar.jjoselibreroc.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;


@Controller
public class MainController {
	
	@Autowired
	private AccountSettingService accountSettingService; 
	
	@Autowired
	UserService userService;
	
	@Autowired
	PrinterService printerService;

	private User usuario;
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	@GetMapping("/")
	public String home() {
		return "index";
	}
	
	@GetMapping("/seePrice")
	public String seePrice() {
		return "seePrice";
	}
	
	@GetMapping("/contact")
	public String contact() {
		return "contact";
	}
	
	public User returnUser() {
	    Authentication auth = SecurityContextHolder
	            .getContext()
	            .getAuthentication();
	    UserDetails userDetail = (UserDetails) auth.getPrincipal();
	    System.out.println("Antes");
	    System.out.println(userDetail);
	    System.out.println("Despues");
	    usuario = userService.findByEmail(userDetail.getUsername());
	    System.out.println(usuario);
	    System.out.println(usuario.getEmail());
	    return usuario;
	}
	
	
	@GetMapping("/filament")
	public String filament() {
		return "user/filament";
	}
	
	
	@GetMapping("/printer")
	public String printer(Model model) {
//		model.addAttribute("printerlist", printerService.findAll());
		model.addAttribute("printerlist", printerService.findAllPrinterOfUser());
		return "user/printer";
	}
	@GetMapping("/createPrinter")
	public String createPartReference(Model model) {
		model.addAttribute("newPrinter", new Printer());
		return "user/createPrinter";
	}
	@PostMapping("/createPrinter/submit")
	public String createPartReferenceSubmit(@ModelAttribute Printer printer) {
		printerService.createPrinter(printer);
		User user = returnUser();
//		List<Printer> printers =  user.getPrinter();
//		printers.add(printer);
//		user.setPrinter(printers);
		user.getPrinter().add(printer);
		userService.saveUser(user);
		return "redirect:/printer";
	}
	
	
	@GetMapping("/part")
	public String part() {
		return "user/part";
	}
	
	@GetMapping("/profile")
	public String profile(Model model) {
		model.addAttribute("newProfile", new AccountSetting());
		return "user/profile";
	}
	@PostMapping("/profile/submit")
	public String createAccountSettingSubmit(@ModelAttribute AccountSetting profile) {
		User user = returnUser();
		profile.setUser(user);
		accountSettingService.createProfile(profile);
		return "redirect:/profile";
	}
	
	@GetMapping("/users")
	public String users() {
		return "admin/users";
	}
	
	@GetMapping("/printerRegistered")
	public String printers() {
		return "admin/printerRegistered";
	}
	
	
}

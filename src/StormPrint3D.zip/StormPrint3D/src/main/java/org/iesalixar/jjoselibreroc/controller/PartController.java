package org.iesalixar.jjoselibreroc.controller;

import org.iesalixar.jjoselibreroc.model.AccountSetting;
import org.iesalixar.jjoselibreroc.model.Filament;
import org.iesalixar.jjoselibreroc.model.Part;
import org.iesalixar.jjoselibreroc.model.Printer;
import org.iesalixar.jjoselibreroc.model.User;
import org.iesalixar.jjoselibreroc.service.FilamentService;
import org.iesalixar.jjoselibreroc.service.PartService;
import org.iesalixar.jjoselibreroc.service.PrinterService;
import org.iesalixar.jjoselibreroc.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class PartController {
	
	@Autowired
	PartService partService;
	
	@Autowired
	UserServiceImpl userService;
	
	@Autowired
	PrinterService printerService;
	
	@Autowired
	FilamentService filamentService;
	
	@GetMapping("/part")
	public String part(Model model) {
		model.addAttribute("partUpdate", new Part());
		model.addAttribute("partlist", partService.findAllPartOfUser());
		model.addAttribute("filamentlist", filamentService.findAllFilamentOfUser());
		model.addAttribute("printerlist", printerService.findAllPrinterOfUser());
		return "user/part";
	}

	@GetMapping("/createPart")
	public String createPart(Model model) {
		model.addAttribute("newPart", new Part());
		model.addAttribute("filamentlist", filamentService.findAllFilamentOfUser());
		model.addAttribute("printerlist", printerService.findAllPrinterOfUser());
		return "user/createPart";
	}
	@PostMapping("/createPart/submit")
	public String createPartSubmit(@ModelAttribute Part part) {
		Printer printer = printerService.getPrinterByNumIdentify(part.getPrinter().getNumIdentify());
		Filament filament = filamentService.getFilamentByNumIdentify(part.getFilament().getNumIdentify());
		part.setPrinter(printer);
		
		filament.setTotalFilament(filament.getTotalFilament()-part.getFilamentLength());//cambio el total del rollo
		filamentService.createFilament(filament);//filamento usado
		
		part.setFilament(filament);
		
		User user = userService.returnUser();
		
		float costeFilamento = part.getFilamentLength() * filament.getPrice();
		AccountSetting profile = user.getAccountSetting();
		float costeLuz = part.getPrintingTime() * profile.getKWH() * printer.getEnergyW();
		part.setPrice(costeFilamento + costeLuz);
		
		
		user.getPart().add(part);
		userService.saveUser(user);
		
		partService.createPart(part);
		return "redirect:/part";
	}
	
	@GetMapping("/part/delete/{numIdentify}")
	public String removee(@PathVariable("numIdentify") int numIdentify) {
		partService.remove(numIdentify);
		return "redirect:/part";
	}
	
	@PostMapping("/updatePart")
	public String updatePart(@ModelAttribute Part partUpdate) {
		partService.updatePart(partUpdate);		
		return "redirect:/part";		
	}
}

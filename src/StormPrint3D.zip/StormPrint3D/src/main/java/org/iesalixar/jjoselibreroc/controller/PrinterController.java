package org.iesalixar.jjoselibreroc.controller;


import org.iesalixar.jjoselibreroc.model.Printer;
import org.iesalixar.jjoselibreroc.model.User;
import org.iesalixar.jjoselibreroc.service.PrinterService;
import org.iesalixar.jjoselibreroc.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class PrinterController {

	@Autowired
	PrinterService printerService;
	
	@Autowired
	UserServiceImpl userService;
	
	@GetMapping("/printer")
	public String printer(Model model) {
//		model.addAttribute("printerlist", printerService.findAll());
		model.addAttribute("printerlist", printerService.findAllPrinterOfUser());
		return "user/printer";
	}
	@GetMapping("/createPrinter")
	public String createPartReference(Model model) {
		model.addAttribute("newPrinter", new Printer());
		return "user/createPrinter";
	}
	@PostMapping("/createPrinter/submit")
	public String createPartReferenceSubmit(@ModelAttribute Printer printer) {
		printerService.createPrinter(printer);
		User user = userService.returnUser();
//		List<Printer> printers =  user.getPrinter();
//		printers.add(printer);
//		user.setPrinter(printers);
		user.getPrinter().add(printer);
		userService.saveUser(user);
		return "redirect:/printer";
	}
	
	@GetMapping("/printer/delete/{numIdentify}")
	public String removee(@PathVariable("numIdentify") int numIdentify) {
		printerService.remove(numIdentify);
		return "redirect:/printer";
	}
	
	@PostMapping("/updatePrinter")
	public String updatePrinter(@ModelAttribute Printer printerUpdate) {
		printerService.updatePrinter(printerUpdate);		
		return "redirect:/printer";		
	}
}

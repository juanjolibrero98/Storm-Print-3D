package org.iesalixar.jjoselibreroc.controller;

import org.springframework.stereotype.Controller;

@Controller
public class RoleController {

}

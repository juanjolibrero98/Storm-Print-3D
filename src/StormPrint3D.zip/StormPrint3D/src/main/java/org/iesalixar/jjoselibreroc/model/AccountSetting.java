package org.iesalixar.jjoselibreroc.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="settingUser")
public class AccountSetting implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	private long id;
	
	@Column
	private String surnames;
	
	@Column
	private String images;
	
	@Column
	private int age;
	
	@Column
	private float KWH;
	
	@Column
	private String country;
	
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;
	

	public AccountSetting(long id, String surnames, String images, int age, float kWH, String country) {
		super();
		this.id = id;
		this.surnames = surnames;
		this.images = images;
		this.age = age;
		KWH = kWH;
		this.country = country;
	}

	public AccountSetting() {
		super();
	}

	public AccountSetting(String surnames, String images, int age, float kWH, String country) {
		super();
		this.surnames = surnames;
		this.images = images;
		this.age = age;
		KWH = kWH;
		this.country = country;
	}
	
	

	public AccountSetting(String surnames, String images, int age, float kWH, String country, User user) {
		super();
		this.surnames = surnames;
		this.images = images;
		this.age = age;
		KWH = kWH;
		this.country = country;
		this.user = user;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getSurnames() {
		return surnames;
	}

	public void setSurnames(String surnames) {
		this.surnames = surnames;
	}

	public String getImages() {
		return images;
	}

	public void setImages(String images) {
		this.images = images;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public float getKWH() {
		return KWH;
	}

	public void setKWH(float kWH) {
		KWH = kWH;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "AccountSetting [id=" + id + ", surnames=" + surnames + ", images=" + images + ", age=" + age + ", KWH="
				+ KWH + ", country=" + country + "]";
	}
	
	

}

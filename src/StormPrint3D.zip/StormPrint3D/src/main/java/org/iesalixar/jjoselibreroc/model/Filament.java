package org.iesalixar.jjoselibreroc.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="filaments")
public class Filament implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	private long id;
	
	@Column
	private String images;
	
	FilamentMaterial material;
	
	@Column
	private String maker;//fabricante

	@Column
	private String color;
	
	FilamentDiameter diameter;
	
	@Column
	private float weight;//peso sin bobina en kg
	
	@Column
	private float price;//precio bobina
	
	@Column
	private float totalFilament;//filamento restante mm

	public Filament() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Filament(String images, FilamentMaterial material, String maker, String color, FilamentDiameter diameter,
			float weight, float price, float totalFilament) {
		super();
		this.images = images;
		this.material = material;
		this.maker = maker;
		this.color = color;
		this.diameter = diameter;
		this.weight = weight;
		this.price = price;
		this.totalFilament = totalFilament;
	}

	public String getImages() {
		return images;
	}

	public void setImages(String images) {
		this.images = images;
	}

	public FilamentMaterial getMaterial() {
		return material;
	}

	public void setMaterial(FilamentMaterial material) {
		this.material = material;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public FilamentDiameter getDiameter() {
		return diameter;
	}

	public void setDiameter(FilamentDiameter diameter) {
		this.diameter = diameter;
	}

	public float getWeight() {
		return weight;
	}

	public void setWeight(float weight) {
		this.weight = weight;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public float getTotalFilament() {
		return totalFilament;
	}

	public void setTotalFilament(float totalFilament) {
		this.totalFilament = totalFilament;
	}
	
	
}

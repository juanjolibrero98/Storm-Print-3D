package org.iesalixar.jjoselibreroc.model;

public enum FilamentDiameter {

	Fine 	("1.75mm"),	//fino
	Medium 	("2.85mm"),	//mediano
	Thick 	("3mm");	//grueso	

	private final String name;
	
	FilamentDiameter(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
}

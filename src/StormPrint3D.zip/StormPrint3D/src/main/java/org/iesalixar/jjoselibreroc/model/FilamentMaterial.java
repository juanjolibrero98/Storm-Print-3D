package org.iesalixar.jjoselibreroc.model;

public enum FilamentMaterial {

	PLA 		("PLA"),	
	ABS 		("ABS"),	
	ASA 		("ASA"),
	PETG 		("PETG"),
	NYLON 		("Nylon"),
	PC 			("PC"),
	HIPS 		("HIPS"),
	PVA 		("PVA"),
	TPUE 		("TPU/TPE"),
	PMMA 		("PMMA"),
	COPPERFILL 	("CopperFill");

	private final String name;
	
	FilamentMaterial(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
}

package org.iesalixar.jjoselibreroc.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="parts")
public class Part implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column
	private String images;
	
	@Column
	private String partName;
	
//	@Column(nullable = false, unique = true, length = 4)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int numIdentify;
	
	@Column
	private int amountPart;//cantidad de piezas
	
	@Column
	private float printingTime;//tiempo de impresión en horas
	
	@Column
	private String quality;//calidad de la impresion
	
	@OneToOne
    @JoinColumn(name = "printer_id")
	Printer printer;
	
	@OneToOne
    @JoinColumn(name = "filament_id")
	Filament filament;
	
	@Column
	private float filamentLength;//longitud de filamento usado

	@Column
	private float price;
	
	public Part() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Part(String images, String partName, int numIdentify, int amountPart, float printingTime, String quality,
			Printer printer, Filament filament, float filamentLength, float price) {
		super();
		this.images = images;
		this.partName = partName;
		this.numIdentify = numIdentify;
		this.amountPart = amountPart;
		this.printingTime = printingTime;
		this.quality = quality;
		this.printer = printer;
		this.filament = filament;
		this.filamentLength = filamentLength;
		this.price = price;
	}

	public String getImages() {
		return images;
	}

	public void setImages(String images) {
		this.images = images;
	}

	public String getPartName() {
		return partName;
	}

	public void setPartName(String partName) {
		this.partName = partName;
	}

	public int getAmountPart() {
		return amountPart;
	}

	public void setAmountPart(int amountPart) {
		this.amountPart = amountPart;
	}

	public float getPrintingTime() {
		return printingTime;
	}

	public void setPrintingTime(float printingTime) {
		this.printingTime = printingTime;
	}

	public String getQuality() {
		return quality;
	}

	public void setQuality(String quality) {
		this.quality = quality;
	}

	public Printer getPrinter() {
		return printer;
	}

	public void setPrinter(Printer printer) {
		this.printer = printer;
	}

	public Filament getFilament() {
		return filament;
	}

	public void setFilament(Filament filament) {
		this.filament = filament;
	}

	public float getFilamentLength() {
		return filamentLength;
	}

	public void setFilamentLength(float filamentLength) {
		this.filamentLength = filamentLength;
	}


	public int getNumIdentify() {
		return numIdentify;
	}


	public void setNumIdentify(int numIdentify) {
		this.numIdentify = numIdentify;
	}


	public float getPrice() {
		return price;
	}


	public void setPrice(float price) {
		this.price = price;
	}
	
	
	

}

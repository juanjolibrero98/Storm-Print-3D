package org.iesalixar.jjoselibreroc.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="printers")
public class Printer implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	private long id;
	
	@Column
	private String images;
	
	@Column
	private String maker;//fabricante
	
	@Column
	private String model;//modelo
	
//	FilamentDiameter diameter;
	@Column
	private float diameter;
	
	@Column
	private float priceHour;//precio/hora de trabajo de la impresora
	
	@Column
	private float energyW;//consumo energético medio(w)

	public Printer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Printer(String images, String maker, String model, float diameter, float priceHour,
			float energyW) {
		super();
		this.images = images;
		this.maker = maker;
		this.model = model;
		this.diameter = diameter;
		this.priceHour = priceHour;
		this.energyW = energyW;
	}

	public String getImages() {
		return images;
	}

	public void setImages(String images) {
		this.images = images;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public float getDiameter() {
		return diameter;
	}

	public void setDiameter(float diameter) {
		this.diameter = diameter;
	}

	public float getPriceHour() {
		return priceHour;
	}

	public void setPriceHour(float priceHour) {
		this.priceHour = priceHour;
	}

	public float getEnergyW() {
		return energyW;
	}

	public void setEnergyW(float energyW) {
		this.energyW = energyW;
	}
	
	

}

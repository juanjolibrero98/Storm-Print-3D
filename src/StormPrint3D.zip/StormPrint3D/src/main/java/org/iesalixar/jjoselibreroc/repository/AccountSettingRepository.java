package org.iesalixar.jjoselibreroc.repository;

import org.iesalixar.jjoselibreroc.model.AccountSetting;
import org.springframework.data.jpa.repository.JpaRepository;


public interface AccountSettingRepository 
	extends JpaRepository<AccountSetting,Long>{

}

package org.iesalixar.jjoselibreroc.repository;

import org.iesalixar.jjoselibreroc.model.Filament;
import org.springframework.data.jpa.repository.JpaRepository;


public interface FilamentRepository 
	extends JpaRepository<Filament,Long>{

}

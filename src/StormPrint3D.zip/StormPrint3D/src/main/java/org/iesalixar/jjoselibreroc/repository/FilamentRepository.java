package org.iesalixar.jjoselibreroc.repository;

import java.util.Optional;

import org.iesalixar.jjoselibreroc.model.Filament;
import org.springframework.data.jpa.repository.JpaRepository;


public interface FilamentRepository 
	extends JpaRepository<Filament,Long>{

	Optional<Filament> findByNumIdentify(int numIdentify);
}

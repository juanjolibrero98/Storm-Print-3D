package org.iesalixar.jjoselibreroc.repository;

import org.iesalixar.jjoselibreroc.model.Printer;
import org.springframework.data.jpa.repository.JpaRepository;


public interface PrinterRepository 
	extends JpaRepository<Printer,Long>{

}

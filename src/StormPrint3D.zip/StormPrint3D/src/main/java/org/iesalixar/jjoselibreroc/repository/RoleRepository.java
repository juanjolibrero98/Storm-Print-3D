package org.iesalixar.jjoselibreroc.repository;

import org.iesalixar.jjoselibreroc.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;


public interface RoleRepository 
	extends JpaRepository<Role,Long>{

}

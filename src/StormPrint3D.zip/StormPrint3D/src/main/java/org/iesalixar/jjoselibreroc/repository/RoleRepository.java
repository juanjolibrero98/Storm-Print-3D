package org.iesalixar.jjoselibreroc.repository;

import java.util.Optional;

import org.iesalixar.jjoselibreroc.model.Filament;
import org.iesalixar.jjoselibreroc.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;


public interface RoleRepository 
	extends JpaRepository<Role,Long>{
	
	Optional<Role> findByName(String name);

}

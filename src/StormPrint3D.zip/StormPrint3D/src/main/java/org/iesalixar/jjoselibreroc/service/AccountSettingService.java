package org.iesalixar.jjoselibreroc.service;

import org.iesalixar.jjoselibreroc.model.AccountSetting;
import org.iesalixar.jjoselibreroc.repository.AccountSettingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class AccountSettingService {

	@Autowired
	AccountSettingRepository accountSettingRepository;
	
	public void createProfile(AccountSetting profile){
		accountSettingRepository.save(profile);		
	}
	
}

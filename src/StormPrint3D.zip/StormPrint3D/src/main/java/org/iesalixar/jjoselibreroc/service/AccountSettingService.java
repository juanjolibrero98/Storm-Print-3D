package org.iesalixar.jjoselibreroc.service;

import java.util.List;
import java.util.Optional;

import org.iesalixar.jjoselibreroc.model.AccountSetting;
import org.iesalixar.jjoselibreroc.model.Filament;
import org.iesalixar.jjoselibreroc.model.Part;
import org.iesalixar.jjoselibreroc.model.User;
import org.iesalixar.jjoselibreroc.repository.AccountSettingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class AccountSettingService {

	@Autowired
	AccountSettingRepository accountSettingRepository;
	
	public void createProfile(AccountSetting profile){
		accountSettingRepository.save(profile);		
	}
	
	public void remove(AccountSetting  setting) {
		accountSettingRepository.delete(setting);
	}
	
	public AccountSetting getAccountSettingByNumProfile(int numProfile) {
		Optional<AccountSetting> profile = accountSettingRepository.findByNumProfile(numProfile);
		return profile.isPresent() ? profile.get() : null;
	}
	
	public AccountSetting updateProfile(AccountSetting b) {
		AccountSetting profileOld = getAccountSettingByNumProfile(b.getNumProfile());
		profileOld.setAge(b.getAge());
		profileOld.setCountry(b.getCountry());
		profileOld .setKWH(b.getKWH());
		profileOld.setSurnames(b.getSurnames());
		
		accountSettingRepository.save(profileOld );
		return profileOld ;	
	}
	
}

package org.iesalixar.jjoselibreroc.service;

import java.util.List;
import java.util.Optional;

import org.iesalixar.jjoselibreroc.model.Filament;
import org.iesalixar.jjoselibreroc.model.Printer;
import org.iesalixar.jjoselibreroc.model.User;
import org.iesalixar.jjoselibreroc.repository.FilamentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class FilamentService {

	@Autowired
	FilamentRepository filamentRepository;
	
	@Autowired
	UserServiceImpl userServiceImpl;
	
	
	public List<Filament> findAll(){
		return filamentRepository.findAll();
	}
	
	public List<Filament> findAllFilamentOfUser(){
//		List<Filament> filaments = filamentRepository.findAll();
		
		User user = userServiceImpl.returnUser();
		List<Filament> filamentsUser = user.getFilament();
		
//		List<Filament> result = new ArrayList<>();
//
//		for (Filament filament : filaments) {
//			if(filament == filamentsUser) {
//				result.add(filament);
//			}
//		}
		
		return filamentsUser;
	}
	
	public void createFilament(Filament filament){
		filamentRepository.save(filament);		
	}
	
	public void remove(int numIdentify) {
		Filament filamentDeleted = getFilamentByNumIdentify(numIdentify);
		User user = userServiceImpl.returnUser();
		
		List<Filament> listaAntigua = user.getFilament();		
		listaAntigua.remove(filamentDeleted);
		
		filamentRepository.delete(filamentDeleted);
	}
	
	public void removeFilament(Filament filament) {	
		filamentRepository.delete(filament);
	}
	
	
	public Filament getFilamentByNumIdentify(int numIdentify) {
		Optional<Filament> filament = filamentRepository.findByNumIdentify(numIdentify);
		return filament.isPresent() ? filament.get() : null;
	}
	
	public Filament updateFilament(Filament b) {
		Filament filamentOld = getFilamentByNumIdentify(b.getNumIdentify());
		filamentOld.setDiameter(b.getDiameter());
		filamentOld.setColor(b.getColor());
		filamentOld.setImages(b.getImages());
		filamentOld.setMaker(b.getMaker());
		filamentOld.setMaterial(b.getMaterial());
		filamentOld.setPrice(b.getPrice());
		filamentOld.setTotalFilament(b.getTotalFilament());
		filamentOld.setWeight(b.getWeight());
	
		filamentRepository.save(filamentOld);
		return filamentOld;	
	}
}


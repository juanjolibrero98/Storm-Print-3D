package org.iesalixar.jjoselibreroc.service;

import org.iesalixar.jjoselibreroc.repository.FilamentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class FilamentService {

	@Autowired
	FilamentRepository filamentRepository;
}


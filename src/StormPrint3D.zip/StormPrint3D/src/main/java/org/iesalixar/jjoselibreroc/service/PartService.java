package org.iesalixar.jjoselibreroc.service;

import java.util.List;
import java.util.Optional;

import org.iesalixar.jjoselibreroc.model.Filament;
import org.iesalixar.jjoselibreroc.model.Part;
import org.iesalixar.jjoselibreroc.model.User;
import org.iesalixar.jjoselibreroc.repository.PartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class PartService {

	@Autowired
	PartRepository partRepository;
	
	@Autowired
	UserServiceImpl userServiceImpl;
	
	
	public List<Part> findAll(){
		return partRepository.findAll();
	}
	
	public List<Part> findAllPartOfUser(){		
		User user = userServiceImpl.returnUser();
		List<Part> partsUser = user.getPart();
		return partsUser;
	}
	
	public void createPart(Part part){
		partRepository.save(part);		
	}
	
	public void remove(int numIdentify) {
		Part partDeleted = getPartByNumIdentify(numIdentify);
		User user = userServiceImpl.returnUser();
		
		List<Part> listaAntigua = user.getPart();		
		listaAntigua.remove(partDeleted);
		
		partRepository.delete(partDeleted);
	}
	
	public void removePart(Part part) {	
		partRepository.delete(part);
	}
	
	public Part getPartByNumIdentify(int numIdentify) {
		Optional<Part> part = partRepository.findByNumIdentify(numIdentify);
		return part.isPresent() ? part.get() : null;
	}
	
	public Part updatePart(Part b) {
		Part partOld = getPartByNumIdentify(b.getNumIdentify());
		partOld.setAmountPart(b.getAmountPart());
		partOld.setFilament(b.getFilament());
		partOld.setFilamentLength(b.getFilamentLength());
		partOld.setImages(b.getImages());
		partOld.setPartName(b.getPartName());
		partOld.setPrinter(b.getPrinter());
		partOld.setPrintingTime(b.getPrintingTime());
		partOld.setQuality(b.getQuality());
		
		partRepository.save(partOld);
		return partOld;	
	}
}

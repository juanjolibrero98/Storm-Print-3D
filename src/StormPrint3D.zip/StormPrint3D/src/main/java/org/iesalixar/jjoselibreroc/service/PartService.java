package org.iesalixar.jjoselibreroc.service;

import org.iesalixar.jjoselibreroc.repository.PartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class PartService {

	@Autowired
	PartRepository partRepository;
}

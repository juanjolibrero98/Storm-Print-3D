package org.iesalixar.jjoselibreroc.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;

import org.iesalixar.jjoselibreroc.model.Printer;
import org.iesalixar.jjoselibreroc.model.User;
import org.iesalixar.jjoselibreroc.repository.PrinterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class PrinterService {

	@Autowired
	PrinterRepository printerRepository;
	
	@Autowired
	UserServiceImpl userServiceImpl;
	
	
	public List<Printer> findAll(){
		return printerRepository.findAll();
	}
	
	public List<Printer> findAllPrinterOfUser(){
		List<Printer> printers = printerRepository.findAll();
		
		User user = userServiceImpl.returnUser();
		List<Printer> printersUser = user.getPrinter();
		
		List<Printer> result = new ArrayList<>();
		
//		for(int i = 0; i < printers.size(); i++) {
//			
//		}
		for (Printer printer : printers) {
			if(printer == printersUser) {
				result.add(printer);
			}
		}
		
		return printersUser;
	}
	
	public void createPrinter(Printer printer){
		printerRepository.save(printer);		
	}
	
	public void remove(int numIdentify) {
		Printer printerDeleted = getPrinterByNumIdentify(numIdentify);
		User user = userServiceImpl.returnUser();
		
		List<Printer> listaAntigua = user.getPrinter();
//		List<Printer> listaNueva = new ArrayList<>();
//		
//		for (Printer printer : listaAntigua) {
//			if(!printer.equals(printerDeleted)) {
//				listaNueva.add(printer);
//			}
//		}
//		
//		user.setPrinter(listaNueva);
		
		listaAntigua.remove(printerDeleted);
		
		
		printerRepository.delete(printerDeleted);
	}
	
	public void removePrinter(Printer printer) {	
		printerRepository.delete(printer);
	}
	
	
	public Printer getPrinterByNumIdentify(int numIdentify) {
		Optional<Printer> printer = printerRepository.findByNumIdentify(numIdentify);
		return printer.isPresent() ? printer.get() : null;
	}
	
	public Printer updatePrinter(Printer b) {
		Printer printOld = getPrinterByNumIdentify(b.getNumIdentify());
		printOld.setDiameter(b.getDiameter());
		printOld.setEnergyW(b.getEnergyW());
		printOld.setImages(b.getImages());
		printOld.setMaker(b.getMaker());
		printOld.setModel(b.getModel());
		printOld.setPriceHour(b.getPriceHour());
		printerRepository.save(printOld);
		return printOld;	
	}
}

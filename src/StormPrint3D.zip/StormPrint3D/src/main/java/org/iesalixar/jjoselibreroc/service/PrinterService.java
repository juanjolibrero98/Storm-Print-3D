package org.iesalixar.jjoselibreroc.service;

import java.util.ArrayList;
import java.util.List;

import org.iesalixar.jjoselibreroc.model.Printer;
import org.iesalixar.jjoselibreroc.model.User;
import org.iesalixar.jjoselibreroc.repository.PrinterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class PrinterService {

	@Autowired
	PrinterRepository printerRepository;
	
	@Autowired
	UserServiceImpl userServiceImpl;
	
	
	public List<Printer> findAll(){
		return printerRepository.findAll();
	}
	
	public List<Printer> findAllPrinterOfUser(){
		List<Printer> printers = printerRepository.findAll();
		
		User user = userServiceImpl.returnUser();
		List<Printer> printersUser = user.getPrinter();
		
		List<Printer> result = new ArrayList<>();
		
//		for(int i = 0; i < printers.size(); i++) {
//			
//		}
		for (Printer printer : printers) {
			if(printer == printersUser) {
				result.add(printer);
			}
		}
		
		return printersUser;
	}
	
	public void createPrinter(Printer printer){
		printerRepository.save(printer);		
	}
}

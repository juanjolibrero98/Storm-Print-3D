package org.iesalixar.jjoselibreroc.service;

import org.iesalixar.jjoselibreroc.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class RoleService {

	@Autowired
	RoleRepository roleRepository;
}

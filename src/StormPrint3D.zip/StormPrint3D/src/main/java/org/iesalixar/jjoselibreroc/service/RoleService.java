package org.iesalixar.jjoselibreroc.service;

import java.util.Optional;

import org.iesalixar.jjoselibreroc.model.Filament;
import org.iesalixar.jjoselibreroc.model.Printer;
import org.iesalixar.jjoselibreroc.model.Role;
import org.iesalixar.jjoselibreroc.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class RoleService {

	@Autowired
	RoleRepository roleRepository;
	
	public Role getRoleByName(String name) {
		Optional<Role> role = roleRepository.findByName(name);
		return role.isPresent() ? role.get() : null;
	}
	
	public void removeRole(Role role) {	
		roleRepository.delete(role);
	}
}

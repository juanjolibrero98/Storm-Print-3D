package org.iesalixar.jjoselibreroc.service;

import org.iesalixar.jjoselibreroc.controller.dto.UserRegistrationDto;
import org.iesalixar.jjoselibreroc.model.User;
import org.springframework.security.core.userdetails.UserDetailsService;


public interface UserService extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);
	User findByEmail(String username);
	User saveUser(User user);
}

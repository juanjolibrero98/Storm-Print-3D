package org.iesalixar.jjoselibreroc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StormPrint3DApplicationTests {

	@Test
	void contextLoads() {
	}

}
